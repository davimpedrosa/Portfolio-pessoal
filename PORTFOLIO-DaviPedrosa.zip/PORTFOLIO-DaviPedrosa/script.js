function mudarIdioma(idioma) {
  localStorage.setItem("idioma", idioma);

  const traducoes = {
    pt: {
      titulo: "Davi Pedrosa",
      "menu-home": "Início",
      "menu-contato": "Contato",
      "menu-trabalhos": "Projetos",
      "sobre-titulo": "Sobre mim",
      "sobre-texto": `
        Meu nome é <strong>Davi Pedrosa</strong>. Sou estudante de Ciência da Computação na CESAR School, com fluência comprovada em inglês por meio do exame <strong>CAE (Cambridge English: Advanced)</strong>. Tenho experiência prática como <strong>SDR</strong> e em <strong>marketing digital</strong>, atuando com estratégias de geração de leads e funil de vendas.<br><br>
        Na área de tecnologia, programo em <strong>Python, JavaScript e HTML</strong>, desenvolvendo soluções web e scripts automatizados. Busco integrar conhecimento técnico, comunicação e mercado para criar soluções impactantes.
      `,
      "contato-titulo": "Entre em contato",
      "contato-texto": "Sinta-se à vontade para me chamar por qualquer uma das redes abaixo!",
      "trabalhos-titulo": "Meus Projetos",
      "desc-recife": "Projeto interativo feito com Python e Arduino para ajudar idosos com demência a relembrar o Recife Antigo através de sons, imagens e botões coloridos.",
      "desc-vida": "Sistema completo de gerenciamento de petshop, incluindo agendamentos, cadastro de pets e gerenciamento de serviços. Desenvolvido em equipe com foco em usabilidade e fluxo de atendimento.",
      rodape: "© 2025 - Davi Pedrosa"
    },
    en: {
      titulo: "Davi Pedrosa",
      "menu-home": "Home",
      "menu-contato": "Contact",
      "menu-trabalhos": "Projects",
      "sobre-titulo": "About me",
      "sobre-texto": `
        My name is <strong>Davi Pedrosa</strong>. I’m a Computer Science student at CESAR School, fluent in English with certification from the <strong>CAE (Cambridge English: Advanced)</strong> exam. I have hands-on experience as an <strong>SDR</strong> and in <strong>digital marketing</strong>, working with lead generation strategies and sales funnels.<br><br>
        In the tech field, I program in <strong>Python, JavaScript, and HTML</strong>, developing web solutions and automation scripts. I aim to integrate technical knowledge, communication, and market insight to create impactful solutions.
      `,
      "contato-titulo": "Get in touch",
      "contato-texto": "Feel free to reach out through any of the networks below!",
      "trabalhos-titulo": "My Projects",
      "desc-recife": "Interactive project using Python and Arduino to help elderly people with dementia reconnect with Recife’s cultural heritage through sounds, images, and color-coded buttons.",
      "desc-vida": "Complete petshop management system including scheduling, pet registration, and service administration. Built in a team with focus on usability and workflow efficiency.",
      rodape: "© 2025 - Davi Pedrosa"
    }
  };

  const textos = traducoes[idioma];

  for (const id in textos) {
    const el = document.getElementById(id);
    if (el) {
      if (id === "sobre-texto" || id.startsWith("desc-")) {
        el.innerHTML = textos[id];
      } else {
        el.textContent = textos[id];
      }
    }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const idiomaSalvo = localStorage.getItem("idioma") || "pt";
  mudarIdioma(idiomaSalvo);
});
